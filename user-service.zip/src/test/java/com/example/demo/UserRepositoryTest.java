package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import com.example.demo.entity.User;
import com.example.demo.repo.UserRepository;

@DataJpaTest
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    void testFindByUsername() {
        User user = new User();
        user.setUsername("vihaan");
        user.setPassword("1234");
        user.setEmail("vihaan@gmail.com");

        userRepository.save(user);

        User found = userRepository.findByUsername("vihaan");
        assertNotNull(found);
        assertEquals("vihaan", found.getUsername());
    }
}

