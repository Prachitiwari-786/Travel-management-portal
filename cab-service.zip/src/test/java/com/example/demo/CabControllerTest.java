package com.example.demo;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.controller.CabController;
import com.example.demo.entity.Cab;
import com.example.demo.service.CabService;

@WebMvcTest(CabController.class)   // ✅ Only loads CabController
public class CabControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CabService cabService;

    @Test
    void testGetCabDetails() throws Exception {
        Cab cab = new Cab();
        cab.setId(1L);
        cab.setSource("Pune");
        cab.setDestination("Mumbai");
        cab.setType("Sedan");

        when(cabService.getCabById(1L)).thenReturn(cab);

        mockMvc.perform(get("/cabs/1"))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.id").value(1))
               .andExpect(jsonPath("$.source").value("Pune"))
               .andExpect(jsonPath("$.destination").value("Mumbai"))
               .andExpect(jsonPath("$.type").value("Sedan"));
    }
}
